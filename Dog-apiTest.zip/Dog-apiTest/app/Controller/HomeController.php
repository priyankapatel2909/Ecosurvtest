<?php
App::uses('HttpSocket', 'Network/Http');
class HomeController extends AppController {

	public function index() {

		if($this->request -> is('post'))
		{
			$data=$this->data;
			if($data['formtype'] == 0)
			{
				if($data['subbread'] != "")
				{
					
					$breadurl="https://dog.ceo/api/breed/".$data['bread']."/".$data['subbread']."/images/random";
					$breadsocket =new HttpSocket();
					$breadresponse=$breadsocket->get($breadurl);
					$breadresult = array();
					$breadresult=json_decode($breadresponse["body"],true);	
					
					$this->set('imagelist',$breadresult['message']);

				}else{
					
					$mainbreadurl="https://dog.ceo/api/breed/".$data['bread']."/images/random";
					$mainbreadscocket =new HttpSocket();
					$mainbreadresponse=$mainbreadscocket->get($mainbreadurl);
					$mainbreadresult = array();
					$mainbreadresult=json_decode($mainbreadresponse["body"],true);	
					
					$this->set('imagelist',$mainbreadresult['message']);
				}
			}else{

				$rendomsocket =new HttpSocket();
				$rendomresponse=$rendomsocket->get('https://dog.ceo/api/breeds/image/random');
				$rendomeFeatchResult = array();
				$rendomeFeatchResult=json_decode($rendomresponse["body"],true);
				$this->set('imagelist',$rendomeFeatchResult['message']);
			}
		}

		$HttpSocket =new HttpSocket();
		$response=$HttpSocket->get('https://dog.ceo/api/breeds/list/all');
		$featchResults = array();
		$featchResults[]=json_decode($response["body"],true);
		//pr($response);die();
		$allData=array();
		$allData=$featchResults[0]['message'];
		//pr(array_keys($allData));die();
		//pr(array_keys($allData[0]));die();
		$breadKeyval=array();
		foreach ($allData as $key => $value) {
			$breadKeyval[$key]=$key;

		}
		//pr($breadKeyval);die();
		$this->set('breadList',$breadKeyval);
		$this->layout="main";
	}
	public function ajax_search($breadNAme=null) {
		
		$SoketbradGet=new HttpSocket();
		$url='https://dog.ceo/api/breed/'.$breadNAme.'/list';
		$response=$SoketbradGet->get($url);

		$featchResults = array();
		$featchResults=json_decode($response["body"],true);

		$breadKeyval=array();
		foreach ($featchResults['message'] as $key => $value) {
			$breadKeyval[$value]=$value;

		}
		//pr($featchResults['message']);die();
		$this->set('subBreadList',$breadKeyval);

		$this->layout="ajax_l";
	}
}
?>